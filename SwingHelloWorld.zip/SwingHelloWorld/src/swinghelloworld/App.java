package swinghelloworld;

import java.awt.FlowLayout;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author willejoerg
 */
public class App extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    private JLabel labelQuestion;
    private JLabel labelWeight;
    private JTextField fieldWeight;
    private JButton buttonTellMe;

    public App() {
        super("Swing HelloWorld");

        initComponents();

        setSize(240, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

//    private static void createAndShowGUI() {
//        final AWTError error = new AWTError("Fehler");
//        final String info = error.toString();
//
//        //Create and set up the window.
//        JFrame frame = new JFrame("Swing HelloWorld");
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//
//        //Add the ubiquitous "Hello World" label.
//        JLabel label = new JLabel("Hello World");
//        frame.getContentPane().add(label);
//
//        //Display the window.
//        frame.pack();
//        frame.setSize(250, 150);
//        frame.setVisible(true);
//    }

    private void initComponents() {
        labelQuestion = new JLabel("How much water should I drink?");
        labelWeight = new JLabel("My weight (kg):");
        fieldWeight = new JTextField(5);
        buttonTellMe = new JButton("Tell Me");

        setLayout(new FlowLayout());

        add(labelQuestion);
        add(labelWeight);
        add(fieldWeight);
        add(buttonTellMe);

        buttonTellMe.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String message = "Buddy, you should drink %.1f L of water a day!";
 
        float weight = Float.parseFloat(fieldWeight.getText());
        float waterAmount = calculateWaterAmount(weight);
 
        message = String.format(message, waterAmount);
 
        JOptionPane.showMessageDialog(this, message);
    }
    
        private float calculateWaterAmount(float weight) {
        return (weight / 10f) * 0.4f;
    }
    
    public static void main(String[] args) {

        if (GraphicsEnvironment.isHeadless()) {
            System.out.println("Print it is headless");
        } else {
            System.out.println("Print it is with GUI");
        }
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.

        new App().setVisible(true);

//        javax.swing.SwingUtilities.invokeLater(App::createAndShowGUI);
    }
}
