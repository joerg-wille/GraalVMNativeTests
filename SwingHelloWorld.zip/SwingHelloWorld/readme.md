Swing AOT Demo using GraalVM

On a new Ubuntu Server 20.04

install:

graalvm-ce-java11-21.2.0

sudo apt install build-essential

sudo apt-get install libz-dev
sudo apt-get install libxi-dev
sudo apt-get install libxtst-de
sudo apt-get install libxrender-dev
sudo apt-get install libfreetype-dev

then run:

./prepare.sh
./build.sh
./SwingHelloWorld