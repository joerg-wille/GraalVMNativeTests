#!/bin/sh

echo "Creating native image ... "
native-image --no-fallback \
             --native-image-info \
             --verbose \
             -H:ConfigurationFileDirectories=config \
             -H:+ReportExceptionStackTraces \
             -H:+ReportUnsupportedElementsAtRuntime \
             -Djava.awt.headless=false \
             -J-Xmx7G \
             -jar dist/SwingHelloWorld.jar \
             SwingHelloWorld
             
# echo "Compressing executable ... "
# upx demo

