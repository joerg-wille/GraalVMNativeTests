#!/bin/sh

echo "Generate the config files ... "
java -agentlib:native-image-agent=config-output-dir=config -jar dist/SwingHelloWorld.jar


